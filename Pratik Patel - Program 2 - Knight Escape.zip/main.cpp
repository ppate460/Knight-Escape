/*--------------------------------------------
   Program 2: Knight Escape
   The objective of this game is to get the white knight to the empty
	square in the upper right-hand corner of the board.
	
	The knight can only move in the way that it does during a traditional
	chess game. This means that a knight can only move in a valid L-shape
	(two squares in a horizontal direction, then one in a vertical direction OR 
	two squares in a vertical direction, then one in a horizontal direction).
		       
   Course: CS 141, Spring 2022
   System: repl.it IDE & ZyBooks 
   Author: 
    
 ---------------------------------------------*/

#include <iostream>		// for input and output
#include <cctype>		   // for toupper()
using namespace std;

// Global variables for the pieces are allowed for this program,
// but will generally not be allowed in the future.
// You will likely want to declare global variables at least for the 25 board positions.
string p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10,
       p11, p12, p13, p14, p15, p16, p17, p18, p19, p20,
       p21, p22, p23, p24, p25;

// Characters of the pieces to be used on the board
// Note that these are global constants, so their values cannot be changed.
const string WhiteKnight = "\u2658";		// White knight character
const string BlackKnight = "\u265E";		// Black knight character
const string BlankPosition = " ";			// Blank position character

//--------------------------------------------------------------------------------
// Display welcome message, introducing the user to the program and
// describing the instructions for the game
void displayWelcomeMessage()
{
    cout << "Program 2: Knight Escape \n"
         << "CS 141, Spring 2022, UIC \n"
         << " \n"
         << "The objective of this puzzle is to get the white knight "
		 << "up to the empty square in the top right corner of the board. "
		 << "Use standard knight moves from a traditional chess game, "
		 << "where a knight moves in an L-shape. \n"
		 << "This means that a knight can only move either "
		 << "1) two squares in a horizontal direction, then one in a vertical direction, OR "
		 << "2) two squares in a vertical direction, then one in a horizontal direction."
		 << " \n"
		 << "Your score decreases by 5 with each valid move, and by 10 with each invalid move. \n"
		 << "Try to complete the puzzle with the smallest number of valid moves!"
    	 << endl;
}//end displayWelcomeMessage()

 
// ----------------------------------------------------------------------
// Display the current board, along with the corresponding positions
// This function makes use of global variables p1..p25, which represent
// each of the positions on the board
void displayBoard()
{
    cout <<"\n"
         <<                          "    Board   " <<                               "      Position \n"
         << " " <<  p1 << " " <<  p2 << " " <<  p3 << " " <<  p4 << " " <<  p5 << "     1  2  3  4  5 \n"
         << " " <<  p6 << " " <<  p7 << " " <<  p8 << " " <<  p9 << " " << p10 << "     6  7  8  9 10 \n"
         << " " << p11 << " " << p12 << " " << p13 << " " << p14 << " " << p15 << "    11 12 13 14 15 \n"
         << " " << p16 << " " << p17 << " " << p18 << " " << p19 << " " << p20 << "    16 17 18 19 20 \n"
         << " " << p21 << " " << p22 << " " << p23 << " " << p24 << " " << p25 << "    21 22 23 24 25 \n"
         << endl;
} //end displayBoard()


// ----------------------------------------------------------------------
// Check the source position to see if the position have a knight or not.
// This function checks whether or not the source position contains 
// a knight or not, returns true if it does.
bool checkBlankPosition(int position1) 
{
  switch ( position1 ) {

    case 1: if (p1  == BlankPosition) { return true; break; } else {return false; break;}
    case 2: if (p2  == BlankPosition) { return true; break; } else {return false; break;}
    case 3: if (p3  == BlankPosition) { return true; break; } else {return false; break;} 
    case 4: if (p4  == BlankPosition) { return true; break; } else {return false; break;}
    case 5: if (p5  == BlankPosition) { return true; break; } else {return false; break;}
    case 6: if (p6  == BlankPosition) { return true; break; } else {return false; break;}
    case 7: if (p7  == BlankPosition) { return true; break; } else {return false; break;}
    case 8: if (p8  == BlankPosition) { return true; break; } else {return false; break;}
    case 9: if (p9  == BlankPosition) { return true; break; } else {return false; break;}
    case 10: if (p10 == BlankPosition) { return true; break; } else {return false; break;}
    case 11: if (p11 == BlankPosition) { return true; break; } else {return false; break;}
    case 12: if (p12 == BlankPosition) { return true; break; } else {return false; break;}
    case 13: if (p13 == BlankPosition) { return true; break; } else {return false; break;}
    case 14: if (p14 == BlankPosition) { return true; break; } else {return false; break;}
    case 15: if (p15 == BlankPosition) { return true; break; } else {return false; break;}
    case 16: if (p16 == BlankPosition) { return true; break; } else {return false; break;}
    case 17: if (p17 == BlankPosition) { return true; break; } else {return false; break;}
    case 18: if (p18 == BlankPosition) { return true; break; } else {return false; break;}
    case 19: if (p19 == BlankPosition) { return true; break; } else {return false; break;}
    case 20: if (p20 == BlankPosition) { return true; break; } else {return false; break;}
    case 21: if (p21 == BlankPosition) { return true; break; } else {return false; break;}
    case 22: if (p22 == BlankPosition) { return true; break; } else {return false; break;}
    case 23: if (p23 == BlankPosition) { return true; break; } else {return false; break;}
    case 24: if (p24 == BlankPosition) { return true; break; } else {return false; break;}
    case 25: if (p25 == BlankPosition) { return true; break; } else {return false; break;}
    }
    return false;

} //end checkBlankPosition()


// ----------------------------------------------------------------------
// Check the destination position to see if the position is empty or not.
// This function checks whether or not the destination position is 
// empty or not, returns true if it does, otherwise false.
bool checkDestinationPosition(int position2) {
  switch ( position2 ) {

    case 1:  if (p1 ==  WhiteKnight || p1  == BlackKnight) {return true; break;} else {return false; break;}
    case 2:  if (p2 ==  WhiteKnight || p2  == BlackKnight) {return true; break;} else {return false; break;}
    case 3:  if (p3 ==  WhiteKnight || p3  == BlackKnight) {return true; break;} else {return false; break;}
    case 4:  if (p4 ==  WhiteKnight || p4  == BlackKnight) {return true; break;} else {return false; break;}
    case 5:  if (p5 ==  WhiteKnight || p5  == BlackKnight) {return true; break;} else {return false; break;}
    case 6:  if (p6 ==  WhiteKnight || p6  == BlackKnight) {return true; break;} else {return false; break;}
    case 7:  if (p7 ==  WhiteKnight || p7  == BlackKnight) {return true; break;} else {return false; break;}
    case 8:  if (p8 ==  WhiteKnight || p8  == BlackKnight) {return true; break;} else {return false; break;}
    case 9:  if (p9 ==  WhiteKnight || p9  == BlackKnight) {return true; break;} else {return false; break;}
    case 10: if (p10 == WhiteKnight || p10 == BlackKnight) {return true; break;} else {return false; break;}
    case 11: if (p11 == WhiteKnight || p11 == BlackKnight) {return true; break;} else {return false; break;}
    case 12: if (p12 == WhiteKnight || p12 == BlackKnight) {return true; break;} else {return false; break;}
    case 13: if (p13 == WhiteKnight || p13 == BlackKnight) {return true; break;} else {return false; break;}
    case 14: if (p14 == WhiteKnight || p14 == BlackKnight) {return true; break;} else {return false; break;}
    case 15: if (p15 == WhiteKnight || p15 == BlackKnight) {return true; break;} else {return false; break;}
    case 16: if (p16 == WhiteKnight || p16 == BlackKnight) {return true; break;} else {return false; break;}
    case 17: if (p17 == WhiteKnight || p17 == BlackKnight) {return true; break;} else {return false; break;}
    case 18: if (p18 == WhiteKnight || p18 == BlackKnight) {return true; break;} else {return false; break;}
    case 19: if (p19 == WhiteKnight || p19 == BlackKnight) {return true; break;} else {return false; break;}
    case 20: if (p20 == WhiteKnight || p20 == BlackKnight) {return true; break;} else {return false; break;}
    case 21: if (p21 == WhiteKnight || p21 == BlackKnight) {return true; break;} else {return false; break;}
    case 22: if (p22 == WhiteKnight || p22 == BlackKnight) {return true; break;} else {return false; break;}
    case 23: if (p23 == WhiteKnight || p23 == BlackKnight) {return true; break;} else {return false; break;}
    case 24: if (p24 == WhiteKnight || p24 == BlackKnight) {return true; break;} else {return false; break;}
    case 25: if (p25 == WhiteKnight || p25 == BlackKnight) {return true; break;} else {return false; break;}
    default: return false; break;
  }
  return false;
  
} //end checkDestinationPosition()


// ----------------------------------------------------------------------
// Main() function of the program, containing the loop that controls
// game play
int main() {

  displayWelcomeMessage();
  
  // Set board values to the default starting position
  p1 = BlackKnight, p2 = BlackKnight, p3 = BlackKnight, p4 = BlackKnight, p5 = BlankPosition,
  p6 = BlackKnight, p7 = BlackKnight, p8 = BlackKnight, p9 = BlackKnight, p10 = BlackKnight,
  p11 = BlackKnight, p12 = BlackKnight, p13 = BlackKnight, p14 = BlackKnight, p15 = BlackKnight,
  p16 = BlackKnight, p17 = BlackKnight, p18 = BlackKnight, p19 = BlackKnight, p20 = BlackKnight,
  p21 = WhiteKnight, p22 = BlackKnight, p23 = BlackKnight, p24 = BlackKnight, p25 = BlackKnight;

  //declared variables
  int moveNumber = 1;
  char menuOption;
  int score = 500;
  int position1, position2;
  string temp;

  displayBoard();
   
  //  Loop that controls game play
  while( score > 0 && p5 != WhiteKnight) {

    cout << "Current score: " << score << endl << endl;
    cout << moveNumber << ". "
             << "Enter one of the following: \n"
			 << "  - M to move a knight from one position to another, \n"
			 << "  - R to reset the board back to the beginning, or \n"
			 << "  - X to exit the game. \n"
			 << "Your choice -> ";
		cin >> menuOption;
		menuOption = toupper(menuOption); // convert user input to uppercase
		
		// If the user entered 'X' to exit,
		// break out of this loop that controls game play
		if ( menuOption == 'X' ) {
      cout << "Exiting..." << endl;
      //break to exit the game
      break;      
    }
		
		// If the user entered 'R' to reset,
		// reset the board back to the beginning
    if (menuOption == 'R' ) {

      //to reset the game and start from the beginning
      cout << endl << "   *** Restarting" << endl;
      score = 500;
      moveNumber = 1;
      p1 = BlackKnight, p2 = BlackKnight, p3 = BlackKnight, p4 = BlackKnight, p5 = BlankPosition,
      p6 = BlackKnight, p7 = BlackKnight, p8 = BlackKnight, p9 = BlackKnight, p10 = BlackKnight,
      p11 = BlackKnight, p12 = BlackKnight, p13 = BlackKnight, p14 = BlackKnight, p15 = BlackKnight,
      p16 = BlackKnight, p17 = BlackKnight, p18 = BlackKnight, p19 = BlackKnight, p20 = BlackKnight,
      p21 = WhiteKnight, p22 = BlackKnight, p23 = BlackKnight, p24 = BlackKnight, p25 = BlackKnight;
      // reset the display board
      displayBoard();
      //use continue to loop throught the gameplay
      continue;
    }
		
		// If the user entered 'M' to move a knight,
		// ask for the position of the knight to be moved
		if (menuOption == 'M' ) {

      //ask user to enter the positions separated by a space
      cout << "Enter the positions from and to, separated by a space "
           << "(e.g. 14 5 to move the knight in position 14 to position 5): ";
      cin  >> position1 >> position2;
      cout << "You have chosen to move a knight from position " << position1 
           << " to position " << position2 << "." << endl;
      
      // Check that FROM position is valid, i.e. within 1-25
      if ( position1 < 1 || position1 > 25 ) {
        cout << "The source position should be a valid position on the board (1-25). "
             << "Try again." << endl;
        // each wrong/invalid move, the score should be decreased by 10
        score -= 10;
        // use continue to keep looping throught the gameplay
        continue;
      }

      // Check that TO position is valid, i.e. within 1-25
      else if ( position2 < 1 || position2 > 25 ) {
        cout << "The destination position should be a valid position on the board (1-25). "
             << "Try again." << endl;
        // each wrong/invalid move, the score should be decreased by 10
        score -= 10;
        // use continue to keep looping throught the gameplay
        continue;
      }

      // Check that the source position has a knight
      else if ( checkBlankPosition(position1) == true ) { 
        cout << "The source position should have a knight. Try again. " << endl;
        // each wrong/invalid move, the score should be decreased by 10
        score -= 10;
        // use continue to keep looping throught the gameplay
        continue;
      }

      // Check that the destination position is empty
      else if ( checkDestinationPosition(position2) == true ) {
        cout << "The destination position should be empty. Try again. " << endl;
        // each wrong/invalid move, the score should be decreased by 10
        score -= 10;
        // use continue to keep looping throught the gameplay
        continue;
      }

      // Check that the move is valid/invalid - knights can only move in an L-shape
      else if ( (position1 >0 && position1 <26) && (position2 >0 && position2 <26) ) { 

        // every possible/valid move when position1 is 1
        if ( position1 == 1 && position2 == 12 ) {
          temp = p1, p1 = BlankPosition, p12 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 1 && position2 == 8 ) {
          temp = p1, p1 = BlankPosition, p8 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 2
        else if ( position1 == 2 && position2 == 11 ) {
          temp = p2, p2 = BlankPosition, p11 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 2 && position2 == 13 ) {
          temp = p2, p2 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 2 && position2 == 9 ) {
          temp = p2, p2 = BlankPosition, p9 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 3        
        else if ( position1 == 3 && position2 == 6 ) {
          temp = p3, p3 = BlankPosition, p6 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 3 && position2 == 12 ) {
          temp = p3, p3 = BlankPosition, p12 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 3 && position2 == 14 ) {
          temp = p3, p3 = BlankPosition, p14 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 3 && position2 == 10 ) {
          temp = p3, p3 = BlankPosition, p10 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 4          
        else if ( position1 == 4 && position2 == 7 ) {
          temp = p4, p4 = BlankPosition, p7 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 4 && position2 == 13 ) {
          temp = p4, p4 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 4 && position2 == 15 ) {
          temp = p4, p4 = BlankPosition, p15 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 5        
        else if ( position1 == 5 && position2 == 8 ) {
          temp = p5, p5 = BlankPosition, p8 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 5 && position2 == 14 ) {
          temp = p5, p5 = BlankPosition, p14 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 6
        else if ( position1 == 6 && position2 == 17 ) {
          temp = p6, p6 = BlankPosition, p17 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 6 && position2 == 13 ) {
          temp = p6, p6 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 6 && position2 == 3 ) {
          temp = p6, p6 = BlankPosition, p3 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 7        
        else if ( position1 == 7 && position2 == 16 ) {
          temp = p7, p7 = BlankPosition, p16 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 7 && position2 == 18 ) {
          temp = p7, p7 = BlankPosition, p18 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 7 && position2 == 14 ) {
          temp = p7, p7 = BlankPosition, p14 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 7 && position2 == 4 ) {
          temp = p7, p7 = BlankPosition, p4 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 8
        else if ( position1 == 8 && position2 == 1 ) {
          temp = p8, p8 = BlankPosition, p1 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 8 && position2 == 11 ) {
          temp = p8, p8 = BlankPosition, p11 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 8 && position2 == 17 ) {
          temp = p8, p8 = BlankPosition, p17 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 8 && position2 == 19 ) {
          temp = p8, p8 = BlankPosition, p19 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 8 && position2 == 15 ) {
          temp = p8, p8 = BlankPosition, p15 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 8 && position2 == 5 ) {
          temp = p8, p8 = BlankPosition, p5 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 9        
        else if ( position1 == 9 && position2 == 2 ) {
          temp = p9, p9 = BlankPosition, p2 = temp, score -= 5, moveNumber++; } 
        else if ( position1 == 9 && position2 == 12 ) {
          temp = p9, p9 = BlankPosition, p12 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 9 && position2 == 18 ) {
          temp = p9, p9 = BlankPosition, p18 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 9 && position2 == 20 ) {
          temp = p9, p9 = BlankPosition, p20 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 10
        else if ( position1 == 10 && position2 == 3 ) {
          temp = p10, p10 = BlankPosition, p3 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 10 && position2 == 13 ) {
          temp = p10, p10 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 10 && position2 == 19 ) {
          temp = p10, p10 = BlankPosition, p19 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 11
        else if ( position1 == 11 && position2 == 2 ) {
          temp = p11, p11 = BlankPosition, p2 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 11 && position2 == 8 ) {
          temp = p11, p11 = BlankPosition, p8 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 11 && position2 == 18 ) {
          temp = p11, p11 = BlankPosition, p18 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 11 && position2 == 22 ) {
          temp = p11, p11 = BlankPosition, p22 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 12       
        else if ( position1 == 12 && position2 == 1 ) {
          temp = p12, p12 = BlankPosition, p1 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 12 && position2 == 3 ) {
          temp = p12, p12 = BlankPosition, p3 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 12 && position2 == 9 ) {
          temp = p12, p12 = BlankPosition, p9 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 12 && position2 == 19 ) {
          temp = p12, p12 = BlankPosition, p19 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 12 && position2 == 23 ) {
          temp = p12, p12 = BlankPosition, p23 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 12 && position2 == 21 ) {
          temp = p12, p12 = BlankPosition, p21 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 13        
        else if ( position1 == 13 && position2 == 6 ) {
          temp = p13, p13 = BlankPosition, p6 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 2 ) {
          temp = p13, p13 = BlankPosition, p2 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 4 ) {
          temp = p13, p13 = BlankPosition, p4 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 10 ) {
          temp = p13, p13 = BlankPosition, p10 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 20 ) {
          temp = p13, p13 = BlankPosition, p20 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 24 ) {
          temp = p13, p13 = BlankPosition, p24 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 22 ) {
          temp = p13, p13 = BlankPosition, p22 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 13 && position2 == 16 ) {
          temp = p13, p13 = BlankPosition, p16 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 14
        else if ( position1 == 14 && position2 == 5 ) {
          temp = p14, p14 = BlankPosition, p5 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 14 && position2 == 3 ) {
          temp = p14, p14 = BlankPosition, p3 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 14 && position2 == 7 ) {
          temp = p14, p14 = BlankPosition, p7 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 14 && position2 == 17 ) {
          temp = p14, p14 = BlankPosition, p17 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 14 && position2 == 23 ) {
          temp = p14, p14 = BlankPosition, p23 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 14 && position2 == 25 ) {
          temp = p14, p14 = BlankPosition, p25 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 15
        else if ( position1 == 15 && position2 == 4 ) {
          temp = p15, p15 = BlankPosition, p4 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 15 && position2 == 8 ) {
          temp = p15, p15 = BlankPosition, p8 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 15 && position2 == 18 ) {
          temp = p15, p15 = BlankPosition, p18 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 15 && position2 == 24 ) {
          temp = p15, p15 = BlankPosition, p24 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 16
        else if ( position1 == 16 && position2 == 7 ) {
          temp = p16, p16 = BlankPosition, p7 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 16 && position2 == 13 ) {
          temp = p16, p16 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 16 && position2 == 23 ) {
          temp = p16, p16 = BlankPosition, p23 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 17
        else if ( position1 == 17 && position2 == 6 ) {
          temp = p17, p17 = BlankPosition, p6 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 17 && position2 == 8 ) {
          temp = p17, p17 = BlankPosition, p8 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 17 && position2 == 14 ) {
          temp = p17, p17 = BlankPosition, p14 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 17 && position2 == 24 ) {
          temp = p17, p17 = BlankPosition, p24 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 18
        else if ( position1 == 18 && position2 == 11 ) {
          temp = p18, p18 = BlankPosition, p11 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 18 && position2 == 7 ) {
          temp = p18, p18 = BlankPosition, p7 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 18 && position2 == 9 ) {
          temp = p18, p18 = BlankPosition, p9 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 18 && position2 == 15 ) {
          temp = p18, p18 = BlankPosition, p15 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 18 && position2 == 25 ) {
          temp = p18, p18 = BlankPosition, p25 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 18 && position2 == 21 ) {
          temp = p18, p18 = BlankPosition, p21 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 19
        else if ( position1 == 19 && position2 == 22 ) {
          temp = p19, p19 = BlankPosition, p22 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 19 && position2 == 12 ) {
          temp = p19, p19 = BlankPosition, p12 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 19 && position2 == 8 ) {
          temp = p19, p19 = BlankPosition, p8 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 19 && position2 == 10 ) {
          temp = p19, p19 = BlankPosition, p10 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 20
        else if ( position1 == 20 && position2 == 9 ) {
          temp = p20, p20 = BlankPosition, p9 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 20 && position2 == 13 ) {
          temp = p20, p20 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 20 && position2 == 23 ) {
          temp = p20, p20 = BlankPosition, p23 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 21        
        else if ( position1 == 21 && position2 == 12 ) {
          temp = p21, p21 = BlankPosition, p12 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 21 && position2 == 18 ) {
          temp = p21, p21 = BlankPosition, p18 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 22
        else if ( position1 == 22 && position2 == 11 ) {
          temp = p22, p22 = BlankPosition, p11 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 22 && position2 == 13 ) {
          temp = p22, p22 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 22 && position2 == 19 ) {
          temp = p22, p22 = BlankPosition, p19 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 23
        else if ( position1 == 23 && position2 == 16 ) {
          temp = p23, p23 = BlankPosition, p16 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 23 && position2 == 12 ) {
          temp = p23, p23 = BlankPosition, p12 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 23 && position2 == 14 ) {
          temp = p23, p23 = BlankPosition, p14 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 23 && position2 == 20 ) {
          temp = p23, p23 = BlankPosition, p20 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 24
        else if ( position1 == 24 && position2 == 17 ) {
          temp = p24, p24 = BlankPosition, p17 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 24 && position2 == 13 ) {
          temp = p24, p24 = BlankPosition, p13 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 24 && position2 == 15 ) {
          temp = p24, p24 = BlankPosition, p15 = temp, score -= 5, moveNumber++; }

        // every possible/valid move when position1 is 24       
        else if ( position1 == 25 && position2 == 18 ) {
          temp = p25, p25 = BlankPosition, p18 = temp, score -= 5, moveNumber++; }
        else if ( position1 == 25 && position2 == 14 ) {
          temp = p25, p25 = BlankPosition, p14 = temp, score -= 5, moveNumber++; }
        
        // else demonstrate invalid move and display the invalid message
        else { 
        cout << "Invalid move. Knights can only move in an L-shape. Try again." << endl;
        // each wrong/invalid move, the score should be decreased by 10
        score -= 10;
        // use continue to keep looping throught the gameplay
        continue;
        }
      }

      //display updated display board after the user move
      displayBoard();
    }
       
  //  Check for a win
  if ( p5 == WhiteKnight ) {
    cout << endl;
    cout << endl << "Congratulations, you did it!" << endl;
  }
  	
  } // end loop for game play

  // Check to see if the user is run out of move and display that use run 
  // out of moves and good luck message
  if (score <= 0 ) {

    cout << "Current score: " << score << endl << endl << endl;
    cout << "You have run out of moves. Try to do better next time!" << endl;
  }

  // no matter what the outcome is, always display greeting message
  cout << "Thank you for playing!";

	return 0;
} 

